#include <Servo.h>

Servo servoBase;
Servo servoHombro;
Servo servoCodo;
Servo servoPinza;

// Pines de los 4 Servos
const int pBase=9, pHombro=10, pCodo=11, pPinza=5;

// Variables de posición
int posBase=90, posHombro=90, posCodo=120, posPinza=45;

// Pines Joysticks
const int joy1Y = A0; // Hombro
const int joy1X = A1; // Base
const int joy2Y = A2; // Codo
const int joy2X = A3; // Pinza

const int suavidad = 18; 
const int zonaMuertaBaja = 462;
const int zonaMuertaAlta = 562;

void setup() {
  servoBase.attach(pBase);
  servoHombro.attach(pHombro);
  servoCodo.attach(pCodo);
  servoPinza.attach(pPinza);

  servoBase.write(posBase);
  servoHombro.write(posHombro);
  servoCodo.write(posCodo);
  servoPinza.write(posPinza);
}

void loop() {
  int j1X = analogRead(joy1X);
  int j1Y = analogRead(joy1Y);
  int j2X = analogRead(joy2X);
  int j2Y = analogRead(joy2Y);

  // Joystick 1: Base (X) y Hombro (Y)
  if (j1X < zonaMuertaBaja) posBase = constrain(posBase - 1, 0, 180);
  else if (j1X > zonaMuertaAlta) posBase = constrain(posBase + 1, 0, 180);

  if (j1Y < zonaMuertaBaja) posHombro = constrain(posHombro - 1, 15, 165);
  else if (j1Y > zonaMuertaAlta) posHombro = constrain(posHombro + 1, 15, 165);

  // Joystick 2: Codo (Y)
  if (j2Y < zonaMuertaBaja) posCodo = constrain(posCodo - 1, 30, 170);
  else if (j2Y > zonaMuertaAlta) posCodo = constrain(posCodo + 1, 30, 170);

  // Joystick 2: Pinza (X) -> Izquierda Abre / Derecha Cierra progresivamente
  if (j2X < zonaMuertaBaja) posPinza = constrain(posPinza - 2, 10, 90); // Abre
  else if (j2X > zonaMuertaAlta) posPinza = constrain(posPinza + 2, 10, 90); // Cierra para sujetar fuerte

  servoBase.write(posBase);
  servoHombro.write(posHombro);
  servoCodo.write(posCodo);
  servoPinza.write(posPinza);

  delay(suavidad);
}